const API_URL = 'http://localhost:3000/api/produtos';
const form = document.getElementById('productForm');
const productList = document.getElementById('productList');

// 1. Função para buscar e exibir produtos (READ)
async function fetchProducts() {
    try {
        const response = await fetch(API_URL);
        const products = await response.json();
        
        productList.innerHTML = ''; // Limpa a lista antes de renderizar

        if (products.length === 0) {
            productList.innerHTML = '<p>Nenhum produto cadastrado.</p>';
            return;
        }

        products.forEach(product => {
            const card = document.createElement('div');
            card.className = 'card';

            const name = document.createElement('h3');
            name.textContent = product.nome;

            const price = document.createElement('div');
            price.className = 'price';
            price.textContent = `R$ ${parseFloat(product.preco).toFixed(2)}`;

            const details = document.createElement('div');
            details.className = 'details';
            
            const size = document.createElement('span');
            size.innerHTML = `Tam: <strong>${product.tamanho}</strong>`; // Using innerHTML here for the <strong> tag

            const color = document.createElement('span');
            color.textContent = `Cor: ${product.cor || 'N/A'}`;

            const separator = document.createElement('span');
            separator.textContent = ' | ';
            
            details.appendChild(size);
            details.appendChild(separator);
            details.appendChild(color);

            const deleteButton = document.createElement('button');
            deleteButton.className = 'btn-delete';
            deleteButton.textContent = 'Excluir';
            deleteButton.onclick = () => deleteProduct(product.id);

            card.appendChild(name);
            card.appendChild(price);
            card.appendChild(details);
            card.appendChild(deleteButton);

            productList.appendChild(card);
        });
    } catch (error) {
        console.error('Erro ao buscar produtos:', error);
        productList.innerHTML = '<p style="color:red">Erro ao carregar produtos do servidor.</p>';
    }
}

// 2. Função para cadastrar produto (CREATE)
form.addEventListener('submit', async (e) => {
    e.preventDefault(); // Impede a página de recarregar

    const newProduct = {
        nome: document.getElementById('nome').value,
        preco: parseFloat(document.getElementById('preco').value),
        tamanho: document.getElementById('tamanho').value,
        cor: document.getElementById('cor').value
    };

    try {
        const response = await fetch(API_URL, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify(newProduct)
        });

        if (response.ok) {
            alert('Produto cadastrado com sucesso!');
            form.reset(); // Limpa o formulário
            fetchProducts(); // Atualiza a lista
        } else {
            alert('Erro ao cadastrar produto.');
        }
    } catch (error) {
        console.error('Erro:', error);
    }
});

// 3. Função para deletar produto (DELETE)
async function deleteProduct(id) {
    if (confirm('Tem certeza que deseja excluir este produto?')) {
        try {
            const response = await fetch(`${API_URL}/${id}`, {
                method: 'DELETE'
            });

            if (response.ok) {
                fetchProducts(); // Atualiza a lista após deletar
            } else {
                alert('Erro ao deletar produto. O produto pode não ter sido encontrado.');
            }
        } catch (error) {
            console.error('Erro ao deletar:', error);
            alert('Erro de conexão ao tentar deletar o produto.');
        }
    }
}

// Carregar produtos ao abrir a página
fetchProducts();