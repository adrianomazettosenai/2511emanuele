# Loja de Roupas - Sistema de Gerenciamento

Este é um projeto simples de uma loja de roupas com um sistema de gerenciamento de estoque, construído com HTML, CSS, JavaScript no frontend e Node.js com Express e Supabase no backend.

## Funcionalidades

- **Cadastro de produtos:** Adicione novas peças de roupa ao estoque com nome, preço, tamanho e cor.
- **Listagem de produtos:** Visualize todos os produtos cadastrados em um grid responsivo.
- **Exclusão de produtos:** Remova produtos do estoque.

## Tecnologias Utilizadas

- **Frontend:**
  - HTML5
  - CSS3 (com Flexbox e Grid para layout responsivo)
  - JavaScript (ES6+, `fetch` para chamadas de API)
- **Backend:**
  - Node.js
  - Express.js
  - Supabase (para o banco de dados PostgreSQL)
  - `dotenv` para gerenciamento de variáveis de ambiente

## Como Executar o Projeto

1. **Pré-requisitos:**
   - Node.js instalado
   - Um projeto Supabase criado com uma tabela `produtos`.

2. **Configure o Backend:**
   - Navegue até a pasta `backend`: `cd backend`
   - O arquivo `.env` já está pré-configurado. Certifique-se de que as variáveis `SUPABASE_URL` e `SUPABASE_KEY` correspondem às suas credenciais do Supabase.
     ```
     PORT=3000
     SUPABASE_URL=SUA_URL_SUPABASE
     SUPABASE_KEY=SUA_CHAVE_SUPABASE
     ```
   - Instale as dependências: `npm install`
   - Inicie o servidor: `npm start` (ou `node server.js`)
   - O servidor backend estará rodando em `http://localhost:3000`.

3. **Abra o Frontend:**
   - Na pasta raiz do projeto, abra o arquivo `index.html` em seu navegador.

## Estrutura do Projeto

```
/
|-- backend/
|   |-- src/
|   |   |-- config/
|   |   |   `-- supabase.js
|   |   |-- controllers/
|   |   |   `-- productController.js
|   |   |-- routes/
|   |   |   `-- productRouters.js
|   |   |-- validators/
|   |   |   `-- productValidator.js
|   |-- .env
|   |-- package.json
|   |-- server.js
|-- .env
|-- index.html
|-- script.js
|-- style.css
|-- README.md
```
