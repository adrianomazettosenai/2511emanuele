// src/config/supabase.js
const { createClient } = require('@supabase/supabase-js');
const fetch = require('node-fetch');

// Validar variáveis de ambiente
if (!process.env.SUPABASE_URL || !process.env.SUPABASE_KEY) {
  console.error('❌ Erro: SUPABASE_URL e SUPABASE_KEY devem estar definidos no .env');
  process.exit(1);
}

// Criar cliente Supabase com polyfill de fetch
const supabase = createClient(
  process.env.SUPABASE_URL,
  process.env.SUPABASE_KEY,
  {
    global: {
      fetch: fetch,
    },
  }
);

module.exports = supabase;